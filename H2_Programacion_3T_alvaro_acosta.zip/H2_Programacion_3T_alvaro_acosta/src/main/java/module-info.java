module org.example.h2_3t_lvaro_acosta {
    requires javafx.controls;
    requires javafx.fxml;
    requires org.mongodb.bson;
    requires org.mongodb.driver.sync.client;
    requires org.junit.jupiter.api;
    requires org.mongodb.driver.core;


    opens org.example.h2_3t_lvaro_acosta to javafx.fxml;
    exports org.example.h2_3t_lvaro_acosta;
}