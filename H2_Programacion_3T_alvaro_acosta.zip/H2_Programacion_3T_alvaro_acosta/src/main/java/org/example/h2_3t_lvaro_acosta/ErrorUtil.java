package org.example.h2_3t_lvaro_acosta;

public class ErrorUtil {

    public static void logError(String message, Throwable throwable) {
        System.err.println(message);
        throwable.printStackTrace();
    }

    public static void logError(String message) {
        System.err.println(message);
    }
}