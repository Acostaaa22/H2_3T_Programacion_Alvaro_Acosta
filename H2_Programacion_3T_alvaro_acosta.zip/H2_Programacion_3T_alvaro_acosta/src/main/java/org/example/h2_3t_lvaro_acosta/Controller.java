package org.example.h2_3t_lvaro_acosta;


import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import org.bson.Document;

import java.util.List;

public class Controller {

    @FXML
    private TextField idField;
    @FXML
    private TextField nameField;
    @FXML
    private TextField emailField;

    @FXML
    private TableView<Document> tableView;
    @FXML
    private TableColumn<Document, String> idColumn;
    @FXML
    private TableColumn<Document, String> nameColumn;
    @FXML
    private TableColumn<Document, String> emailColumn;

    private CRUDOperations crudOperations;

    @FXML
    public void initialize() {
        // Initialize columns
        idColumn.setCellValueFactory(new PropertyValueFactory<>("id"));
        nameColumn.setCellValueFactory(new PropertyValueFactory<>("name"));
        emailColumn.setCellValueFactory(new PropertyValueFactory<>("email"));

        // Initialize CRUD operations
        crudOperations = new CRUDOperations(MongoDBUtil.getDatabase().getCollection("yourCollection"));

        // Load data into table
        loadTableData();
    }

    @FXML
    private void handleCreate() {
        Document doc = new Document("_id", idField.getText())
                .append("name", nameField.getText())
                .append("email", emailField.getText());
        crudOperations.create(doc);
        loadTableData();
    }

    @FXML
    private void handleRead() {
        Document doc = crudOperations.read(idField.getText());
        if (doc != null) {
            nameField.setText(doc.getString("name"));
            emailField.setText(doc.getString("email"));
        }
    }

    @FXML
    private void handleUpdate() {
        Document doc = new Document("name", nameField.getText())
                .append("email", emailField.getText());
        crudOperations.update(idField.getText(), doc);
        loadTableData();
    }

    @FXML
    private void handleDelete() {
        crudOperations.delete(idField.getText());
        loadTableData();
    }

    private void loadTableData() {
        List<Document> documents = crudOperations.readAll();
        ObservableList<Document> data = FXCollections.observableArrayList(documents);
        tableView.setItems(data);
    }
}
