package org.example.h2_3t_lvaro_acosta;

import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoDatabase;
import com.mongodb.MongoException;

public class MongoDBUtil {

    private static MongoClient mongoClient;
    private static MongoDatabase database;

    public static void connect(String uri, String dbName) {
        try {
            mongoClient = MongoClients.create(uri);
            database = mongoClient.getDatabase(dbName);
            System.out.println("Conectado a la base de datos exitosamente");
        } catch (MongoException e) {
            System.err.println("Ocurrió un error al intentar conectarse a la base de datos: " + e.getMessage());
        }
    }

    public static MongoDatabase getDatabase() {
        return database;
    }

    public static void close() {
        if (mongoClient != null) {
            mongoClient.close();
            System.out.println("Conexión a la base de datos cerrada exitosamente");
        }
    }
}