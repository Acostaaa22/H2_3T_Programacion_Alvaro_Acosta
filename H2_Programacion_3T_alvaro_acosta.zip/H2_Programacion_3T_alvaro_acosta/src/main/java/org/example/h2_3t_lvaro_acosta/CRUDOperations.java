package org.example.h2_3t_lvaro_acosta;

import com.mongodb.client.MongoCollection;
import org.bson.Document;

import java.util.ArrayList;
import java.util.List;

public class CRUDOperations {

    private final MongoCollection<Document> collection;

    public CRUDOperations(MongoCollection<Document> collection) {
        this.collection = collection;
    }

    public void create(Document document) {
        collection.insertOne(document);
    }

    public Document read(String id) {
        return collection.find(new Document("_id", id)).first();
    }

    public List<Document> readAll() {
        return collection.find().into(new ArrayList<>());
    }

    public void update(String id, Document updatedDocument) {
        collection.updateOne(new Document("_id", id), new Document("$set", updatedDocument));
    }

    public void delete(String id) {
        collection.deleteOne(new Document("_id", id));
    }
}
