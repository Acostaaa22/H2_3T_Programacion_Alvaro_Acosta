package org.example.h2_3t_lvaro_acosta;

import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import org.bson.Document;
import org.junit.jupiter.api.*;


import static org.junit.jupiter.api.Assertions.*;

@TestInstance(TestInstance.Lifecycle.PER_CLASS)
public class CRUDOperationsTest {

    private CRUDOperations crudOperations;
    private MongoCollection<Document> collection;

    @BeforeAll
    public void setup() {
        MongoDatabase database = MongoDBUtil.getDatabase();
        collection = database.getCollection("testCollection");
        crudOperations = new CRUDOperations(collection);
    }

    @BeforeEach
    public void clearCollection() {
        collection.deleteMany(new Document());
    }

    @Test
    public void testCreateRead() {
        Document doc = new Document("_id", "1").append("name", "Alvaro").append("email", "alvaroacosta@gmail.com");
        crudOperations.create(doc);

        Document readDoc = crudOperations.read("1");
        assertNotNull(readDoc);
        assertEquals("John", readDoc.getString("name"));
    }

    @Test
    public void testUpdate() {
        Document doc = new Document("_id", "1").append("name", "Alvaro").append("email", "alvaroacosta@gmail.com");
        crudOperations.create(doc);

        Document updatedDoc = new Document("name", "Alvaro Acosta");
        crudOperations.update("1", updatedDoc);

        Document readDoc = crudOperations.read("1");
        assertNotNull(readDoc);
        assertEquals("Alvaro Acosta", readDoc.getString("name"));
    }

    @Test
    public void testDelete() {
        Document doc = new Document("_id", "1").append("name", "Alvaro").append("email", "alvaroacosta@gmail.com");
        crudOperations.create(doc);

        crudOperations.delete("1");

        Document readDoc = crudOperations.read("1");
        assertNull(readDoc);
    }

    @AfterAll
    public void tearDown() {
        MongoDBUtil.close();
    }
}