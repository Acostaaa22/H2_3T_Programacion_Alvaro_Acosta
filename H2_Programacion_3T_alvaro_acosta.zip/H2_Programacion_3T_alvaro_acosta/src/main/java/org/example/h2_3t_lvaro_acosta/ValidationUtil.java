package org.example.h2_3t_lvaro_acosta;

import org.bson.Document;

import java.util.regex.Pattern;

public class ValidationUtil {

    public static boolean isValidDocument(Document document) {
        return document.containsKey("name") && document.containsKey("email") && isValidEmail(document.getString("email"));
    }

    private static boolean isValidEmail(String email) {
        String emailRegex = "^[a-zA-Z0-9_+&*-]+(?:\\.[a-zA-Z0-9_+&*-]+)*@(?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,7}$";
        Pattern pat = Pattern.compile(emailRegex);
        return pat.matcher(email).matches();
    }
}
